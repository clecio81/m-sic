module.exports = {
    "prefix": "$",
    "region": "ar",
    "token": "THIS IS SUPER HIGH SECRET!!!"
}